/// <reference path="globals/angular-cookies/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
