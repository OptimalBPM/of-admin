
//all of the tasks themselves are contained in the gulp/tasks directory,
//which is accessed through gulp/index.js

require('./gulp');
