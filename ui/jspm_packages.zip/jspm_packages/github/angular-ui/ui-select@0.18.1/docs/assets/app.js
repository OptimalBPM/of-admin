var module = angular.module('ui.select.pages', ['plunkr']);
